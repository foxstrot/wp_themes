=== NVX MFC.RU ===
Contributors: foxstrot
Requires at least: WordPress 4.2
Tested up to: WordPress 4.7.2
Stable tag: 1.0
Tags: two-columns, one-column, left-sidebar, right-sidebar, custom-header
License: GNU General Public License v2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html
 
== Description ==

NVX MFC.RU is theme for for multipurpose centers 

== Installation ==

1. In your admin panel, go to Appearance -> Themes and click the 'Add New' button.
2. Type in NVX MFC.RU in the search form and press the 'Enter' key on your keyboard.
3. Click on the 'Activate' button to use your new theme right away.
4. Navigate to Appearance > Theme Options in your admin panel and customize to taste.


== Changelog ==

= 1.0 =

* Release



== Copyright ==

Author: Ltd. Netvox Lab